// config.js
require('dotenv').config();

module.exports = {
  port: process.env.PORT || 5000,
  dbConfig: {
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
  },
  jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret_key',
};
